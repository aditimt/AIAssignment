import logo from './logo.svg';

import './App.css';

import {OpenAI} from "openai"

import HomePage from './Components/organisms/homePage';
import { useLayoutEffect, useState } from 'react';

function App() {

  const [openAi, updateOpenAi] = useState([]);

  useLayoutEffect(()=>{

    const openai = new OpenAI({organization: "org-l49bIefIlGdX5paSyzQKPYQ1",
    apiKey: "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",dangerouslyAllowBrowser:true});

    updateOpenAi(openai);
  },[])

  return (
    <div className="App">
      <HomePage openAi={openAi}/>
    </div>
  );
}

export default App;
