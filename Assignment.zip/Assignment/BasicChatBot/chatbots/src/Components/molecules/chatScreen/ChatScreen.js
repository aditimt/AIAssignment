import React, { useState } from 'react';

import TextField from '@mui/material/TextField';
import { Button } from '@mui/material';

import styles from "./chatScreen.module.css";
import ContentScreen from '../contentScreen';

const ChatScreen = ({handleQuestion, content, isLoading}) =>{

    const [message, updateMessage] = useState("");

    const handleInputMessageChange = (event)=>{
        event.preventDefault();
        updateMessage(event.target.value);
    }

    const handleKeyDown = (event)=>{
        if(event.key === "Enter")
        {
            handleSendMessage(event);
        }
    }

    const handleSendMessage = (event)=>{
        event.preventDefault();
        handleQuestion(message);
        updateMessage("");
    }

    return (
        <div className={styles.container}>
            <div className={styles.header}>
            </div>
            <ContentScreen content={content} isLoading={isLoading}/>
            <div className={`${styles.container} ${styles.formContainer}`}>
                <TextField style={{width:"90%"}} id="outlined-basic" label="Please Enter your text here" value={message} variant="outlined" onChange={handleInputMessageChange} onKeyDown={handleKeyDown}/>
                <Button style={{height: "45px", marginTop:'5px'}} variant="outlined" onClick={handleSendMessage}>Ask</Button>
            </div>
        </div>
    )
}

export default ChatScreen;