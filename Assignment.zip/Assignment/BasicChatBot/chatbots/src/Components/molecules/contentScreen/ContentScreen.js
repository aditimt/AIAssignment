import React from "react";
import _map from "lodash/map"

import CircularProgress from '@mui/material/CircularProgress';

import styles from "./contentScreen.module.css"

const ContentScreen = ({content = [],isLoading})=>{
    return(
        <div className={styles.container}>
            <div><b>{content.length > 1 ? content[1]?.context : "How can I help You Today" }</b></div>
            {_map(content,(data)=>{
                let role = data.role;
                role = role.charAt(0).toString().toUpperCase()+role.substring(1,role.length)
                return (
                    <div className={styles.messageRow}><b>{role} </b>: {data.content}</div>
                )
            })}
            {isLoading && <div className={styles.circularProgress}>{ <CircularProgress />}</div>}
        </div>
    )
}

export default ContentScreen;