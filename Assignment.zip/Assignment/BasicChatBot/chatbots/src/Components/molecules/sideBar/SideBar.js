import React, { useState } from "react";

import { Button } from "@mui/material";
import { styled } from '@mui/material/styles';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import TextField from '@mui/material/TextField';

import styles from "./sideBar.module.css";

const VisuallyHiddenInput = styled('input')({
  clip: 'rect(0 0 0 0)',
  clipPath: 'inset(50%)',
  height: 1,
  overflow: 'hidden',
  position: 'absolute',
  bottom: 0,
  left: 0,
  whiteSpace: 'nowrap',
  width: 1,
});

const SideBar = () =>{

    const [files,updateFile] = useState([]);

    const [pdfContext, setPdfContext] = useState("");

    const handlePdfContextChange = (event)=>{
        setPdfContext(event.target.value);
    }

    const handleFilesUpload = ()=>{
        const data = new FormData();
        for (let i = 0; i < files.length; i++) {
            data.append('files', files[i]);
          }
        
        data.append("context",pdfContext);

        fetch("http://localhost:8080/",{
            method:"POST",
            body:data,
        })
        .then((res)=>{
            console.log("Successfully Uploaded  ", res);
        })
        .catch((error)=>{
            console.log(error);
        })

        setPdfContext("");
    }

    const handleSingleFileUpdate = (event)=>{
        updateFile([...files,...event.target.files]);
    }

    return (
        <div className={styles.container}>
            <div className={styles.fileUploadButton}>
                <div className={styles.textFieldContainer}>
                    <TextField onChange={handlePdfContextChange} required value={pdfContext} size={"small"} id="filled-basic" label="Outlined secondary" color="warning" variant="outlined" focused sx={{ input: { color: 'white' } }}/>
                </div>
                <Button component="label" variant="contained" startIcon={<CloudUploadIcon />}>
                    Select Files
                    <VisuallyHiddenInput type="file" onChange={handleSingleFileUpdate} multiple/>
                </Button>
                <Button size="small" variant="contained" onClick={handleFilesUpload}>
                    Upload Files
                </Button>
            </div>
        </div>
    )
}

export default SideBar;