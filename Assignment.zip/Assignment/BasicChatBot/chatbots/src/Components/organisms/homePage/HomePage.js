import React, { useReducer, useState } from "react";
import ChatScreen from "../../molecules/chatScreen";
import SideBar from "../../molecules/sideBar";

import styles from './homePage.module.css';

const HomePage = ({openAi}) =>{
    const [content,updateContent] = useState([]);

    const [isLoading, setIsLoading] = useState(false);

    const handleQuestion = (message)=>{
        setIsLoading(true);
        const newContent = content;
        newContent.push({ role: "user", content: message });

        fetch("http://localhost:8080/embedded",{
            method:'POST',
            body:JSON.stringify({
                message :[{ role: "system", content: "You are a helpful assistant." },...newContent], 
            }),
            headers:{
                'content-type':"application/json"
            }
        })
        .then((res)=>{
            return res.json();
        })
        .then((data)=>{
            updateContent([...content,data]);
            setIsLoading(false);
        })
        .catch((e)=>{
            console.log(e);
            setIsLoading(false);
        })
        
        // openAi.chat.completions.create({
        //     messages: [{ role: "system", content: "You are a helpful assistant." },...newContent],
        //     model: "gpt-3.5-turbo",
        // })
        // .then((res)=>{

        //     const newRes = JSON.parse(JSON.stringify(res));

        //     const {choices} = newRes;

        //     const {message} = choices[0];

        //     updateContent([...newContent,message]);
        //     setIsLoading(false);
        // })
        // .catch((error)=>{
        //     console.log(error);
        //     setIsLoading(false);
        // })

        // updateContent([...newContent]);
    }

    return (
        <div className={styles.container}>
            <SideBar />
            <ChatScreen handleQuestion={handleQuestion} content={content} isLoading={isLoading}/>
        </div>
    )
}

export default HomePage;