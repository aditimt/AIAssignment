function dotProduct(arr1, arr2) {
  if(arr1.length<arr2.length)
  {
    return arr1.reduce((acc, val, index) => acc + val * arr2[index], 0);
  }
  return arr2.reduce((acc, val, index) => acc + val * arr1[index], 0)
  }
  
  function magnitude(arr) {
    return Math.sqrt(arr.reduce((acc, val) => acc + val * val, 0));
  }
  
module.exports = function cosineSimilarity(arr1, arr2) {
  
    const dotProd = dotProduct(arr1, arr2);
    const magArr1 = magnitude(arr1);
    const magArr2 = magnitude(arr2);
  
    if (magArr1 === 0 || magArr2 === 0) {
      throw new Error("Magnitude of at least one of the arrays is zero");
    }
  
    return dotProd / (magArr1 * magArr2);
  }