const express = require("express");
const cors = require("cors");
const app = express();

const fetch = require("node-fetch");

const Excel = require('exceljs');
const xl = require("excel4node");
const cosineSimilarity = require("./helper/formulaes");

const bodyParser = require('body-parser')
var workBook = new Excel.Workbook();
const fs = require("fs");

const multer = require("multer");
const upload = multer({ dest: 'uploads/' });

const wb = new xl.Workbook();
const ws = wb.addWorksheet('Embedded ChatBot Data');

const headingColumnNames = [
    "Text",
    "Embeddings",
    "Context"
]

let headingColumnIndex = 1;

headingColumnNames.forEach(heading => {
    ws.cell(1, headingColumnIndex++)
        .string(heading)
});

app.use(cors({ origin: '*' }))

app.use(bodyParser.json())

app.post("/embedded",(req,res)=>{
    const { body } = req || {};
    const { message } = body || {};
    let finalContent = "";
    let similarityValue = 0;
    let embeddedContext="";

    fetch("https://api.openai.com/v1/embeddings",{
        method:"POST",
        headers:{
            "Content-Type":"application/json",
            "Authorization": "Bearer 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",
        },
        body:JSON.stringify({
            "input":message[message.length-1].content,
            "model":"text-embedding-ada-002",
        })
    })
    .then((response)=>{
        return response.json();
    })
    .then((data)=>{
        workBook.xlsx.readFile("./filename.xlsx")
        .then(()=>{
            let sh = workBook.getWorksheet("Embedded ChatBot Data");
            for (i = 2; i <= sh.rowCount; i++) {
                let text = sh.getRow(i).getCell(1).value;
                let embeddedData = sh.getRow(i).getCell(2).value;
                let existingContext = sh.getRow(i).getCell(3).value;

                let comparedResult = cosineSimilarity(data.data[0].embedding,JSON.parse(embeddedData));
                
                if(comparedResult>similarityValue)
                {
                    finalContent=text;
                    similarityValue=comparedResult;
                    embeddedContext=existingContext;
                }
            }
            res.send({role:'assistent',content:finalContent,context:embeddedContext})
        })
    })
})

app.post("/",upload.array('files',10),(req,res)=>{

    const {body} = req || {};

    const {context} = body || {};

    try {
        let fileRowCount =0;
        workBook.xlsx.readFile("./filename.xlsx")
        .then(()=>{
            let sh=workBook.getWorksheet("Embedded ChatBot Data");
            fileRowCount= workBook.getWorksheet("Embedded ChatBot Data").rowCount -1;
            for (i = 1; i <= sh.rowCount; i++) {
                let text = sh.getRow(i).getCell(1).value;
                ws.cell(i,1).string(text);
                let embeddedData = sh.getRow(i).getCell(2).value;
                ws.cell(i,2).string(embeddedData);
                let embeddedContext = sh.getRow(i).getCell(3).value;
                ws.cell(i,3).string(embeddedContext);
            }
        })
        .catch((e)=>{
            console.log(e);
        })

        let fetchRequests=[];

        for(let count=0;count<req.files.length;count++)
        {
            const fileData = fs.readFileSync(`./uploads/${req.files[count].filename}`, 'utf8');
            const request = fetch("https://api.openai.com/v1/embeddings",{
                method:"POST",
                headers:{
                    "Content-Type":"application/json",
                    "Authorization": "Bearer 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",
                },
                body:JSON.stringify({
                    "input":fileData,
                    "model":"text-embedding-ada-002",
                })
            })
            .then((res)=>{
                return res.json();
            })
            fetchRequests.push(request);
        }
        Promise.all(fetchRequests)
        .then((data)=>{
            for(let counter=0;counter<data.length;counter++)
            {
                const fileData = fs.readFileSync(`./uploads/${req.files[counter].filename}`, 'utf8');
                let rowIndex = fileRowCount+2+counter;
                let updatedRes = data[counter].data;
                updatedRes.forEach( record => {
                    let columnIndex = 1;
                    ws.cell(rowIndex,columnIndex).string(fileData);
                    columnIndex++;
                    ws.cell(rowIndex,columnIndex).string(JSON.stringify(record.embedding));
                    columnIndex++;
                    ws.cell(rowIndex,columnIndex).string(context);
                        rowIndex++;
                });    
            }
            wb.write('filename.xlsx');
        })
        .catch((error)=>{
            console.log("Error is as follows  "+error);
        })
    } catch (err) {
        console.error(err);
      }
    res.send("Suceess");
})



app.listen(8080,()=>{
    console.log("Listening on the port : 8080");
});