
1. Unzip the whole file.
2. Then go into the project and open two terminals.

Steps for First terminal
1. Go into the root directory of the project and do init install
2. Then go into the server folder and do "node app.js"

Steps for second terminal
1. Go into the chatbots folder
2. Then do "npx install -g create-react-app"
3. Them do "npm start"

Website will appear in the port : 3000 by default , one can also change it by going into the package.json
The backend will work into the port : 8080


Video url: https://drive.google.com/file/d/1zvASlpTIfqUaBE1fZHK0lU6TqGIvQrsa/view?usp=drive_link
